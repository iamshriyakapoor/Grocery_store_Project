import sql_connection

con=sql_connection.get_sql_connection()
cursor =con.cursor